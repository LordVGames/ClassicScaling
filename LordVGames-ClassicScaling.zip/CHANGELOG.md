## v2.0.3

- Fixed enemy buff being added to when restarting a run without exiting to menu

## v2.0.2

- Fixed sync packet for enemy buff on stage change erroring, even in singeplayer

## v2.0.1

- Mod now uses ReturnsAPI

## v2.0.0

- Added classic scaling for the director's points/credits scaling and the enemy_buff time scaling (the latter part only really affects multiplayer)
- Hopefully future-proofed the mod enough so the game won't die when a scanned memory address isn't found

## v1.1.4

- Fixed a value when getting the classic enemy_buff value being nil

## v1.1.3

- Fixed mod for RoRR v1.1.0

## v1.1.2

- Fixed multiplayer clients not receiving the new `enemy_buff` value from stage change, which caused various issues

### v1.1.1

- Forgot to remove the bit about boar beach from the readme lmao

### v1.1.0

- Each section of changes (elite stat changes/loot scaling changes/enemy strength scaling on stage change) can now be configured on/off

### v1.0.1

- Removed this mod's "stages_passed" counter subtraction when going to boar beach since RoRR already does it

### v1.0.0

- Initial release