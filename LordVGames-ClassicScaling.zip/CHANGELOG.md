### v1.0.1

- Removed this mod's "stages_passed" counter subtraction when going to boar beach since RoRR already does it

### v1.0.0

- Initial release