## v1.1.2

- Fixed multiplayer clients not receiving the new `enemy_buff` value from stage change, which caused various issues

### v1.1.1

- Forgot to remove the bit about boar beach from the readme lmao

### v1.1.0

- Each section of changes (elite stat changes/loot scaling changes/enemy strength scaling on stage change) can now be configured on/off

### v1.0.1

- Removed this mod's "stages_passed" counter subtraction when going to boar beach since RoRR already does it

### v1.0.0

- Initial release