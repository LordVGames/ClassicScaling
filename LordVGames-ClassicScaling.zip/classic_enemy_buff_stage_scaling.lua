---@diagnostic disable: undefined-field, param-type-mismatch


-- in the function "gml_Script_stage_goto_next_gml_Object_oDirectorControl_Create_0"
--[[
scanning for these:
140F5BC4B 48 8D 55 10                                   lea     rdx, [rbp+0A0h+stages_passed_3]     << var_90
140F5BC4F 49 8B CD                                      mov     rcx, [rbp+0B0h+gamemode_check]      << r13
140F5BC52 E8 39 E5 10 FF                                call    RValue_Add
]]
local before_enemy_buff_add_pointer = memory.scan_pattern("48 8D 55 10 49 8B CD E8 39 E5 10 FF")


-- add 4 is done to skip past the "lea rdx" line
-- this hook happens when transitioning to a stage but BEFORE the stage actually transitions
memory.dynamic_hook_mid("remove_returns_per_stage_difficulty_scaling", {"rdx"}, {"RValue*"}, 0, before_enemy_buff_add_pointer:add(4),
function(args)
    if not ConfigEntry_ClassicEnemyBuffStageScaling:get() then
        return
    end

    -- fuck off
    args[1].value = 0
end)


-- ror1 chose the enemy_buff number depending on the stage name, but all the stages that shared a stage # had the same enemy_buff additions anyways.
-- idk how rorml handled modded stages (and especially ss1 with it's special stages) but if there's some special handling i'll add it later
local classic_enemy_buff_per_stage =
{
    [1] = 0.4,
    [2] = 0.4,
    [3] = 0.5,
    [4] = 0.45,
    [5] = 0.45
}


local sync_new_enemy_buff_packet = Packet.new()
-- have to check for specific stages in here beacause the memory hook is too early to get the new stage id
-- this happens after our memory hook but it's STILL not late enough for the stage to actually change
-- so the stage name/stages passed will be of the previous stage
-- luckily the result.value is the id the next stage, so we can use that
gm.post_script_hook(gm.constants.stage_roll_next,
function(self, other, result, args)
    if not ConfigEntry_ClassicEnemyBuffStageScaling:get() then
        return
    end


    --log.debug("stage_roll_next")
    -- avoid doing this on menus
    if Global.level_name == "" then
        return
    end
    --log.debug("level name is " .. Global.level_name)
    --log.debug("level ID is " .. Global.stage_id)
    --log.debug("result.value (new level ID) is " .. result.value)
    local director = GM._mod_game_getDirector()
    if director == nil then
        log.warning("director was NIL in stage_roll_next - not adding to enemy_buff!")
        return
    end


    local enemy_buff_add
    -- when entering contact light
    -- it's handled separately here since you can go here any stage post-loop and we need to avoid adding the wrong number to enemy_buff
    if result.value == 9 then
        enemy_buff_add = 0.45
        return
    else
        -- don't need to check for boar beach since rorr's existing functionality mixed with this mod leads to classic functionality regardless
        local stage_number_in_loop = math.fmod(director.stages_passed + 1, 5)
        -- mfw arrays start at 1 so i can't have a value in a table starting at 0
        if stage_number_in_loop == 0 then
            stage_number_in_loop = 5
        end
        enemy_buff_add = classic_enemy_buff_per_stage[stage_number_in_loop]
    end

    local sync_new_enemy_buff_message = sync_new_enemy_buff_packet:message_begin()
    if gm._mod_net_isHost() and gm._mod_net_isOnline() then
        sync_new_enemy_buff_message:write_float(enemy_buff_add)
        sync_new_enemy_buff_message:send_to_all()
    end

    --log.debug("stages passed is " .. director.stages_passed)
    --log.debug("stage_number_in_loop is " .. stage_number_in_loop)
    --log.debug("before: " .. director.enemy_buff)
    director.enemy_buff = director.enemy_buff + enemy_buff_add
    --log.debug("after: " .. director.enemy_buff)
end)

sync_new_enemy_buff_packet:onReceived(function(sync_new_enemy_buff_message)
    local director = GM._mod_game_getDirector()
    if director == nil then
        log.warning("CLIENT director was NIL in stage_roll_next - not adding to enemy_buff!")
        return
    end

    local enemy_buff_add = sync_new_enemy_buff_message:read_float()
    --log.debug("CLIENT before: " .. director.enemy_buff)
    director.enemy_buff = director.enemy_buff + enemy_buff_add
    --log.debug("CLIENT after: " .. director.enemy_buff)
end)